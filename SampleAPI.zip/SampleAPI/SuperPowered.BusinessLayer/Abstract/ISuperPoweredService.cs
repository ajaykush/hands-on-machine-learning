﻿using System;
using System.Collections.Generic;
using System.Text;
using SuperPowered.DomainModel.Entities;

namespace SuperPowered.BusinessLayer.Abstract
{
    public interface ISuperPoweredService
    {
        IEnumerable<SuperPower> Superpowers { get; }
        
        IEnumerable<SuperPower> GetSuperPowers();
     
    }
}
