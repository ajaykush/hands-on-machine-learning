﻿using SuperPowered.BusinessLayer.Abstract;
using SuperPowered.DomainModel.Abstract;
using SuperPowered.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperPowered.BusinessLayer.Concrete
{
    public class SuperPoweredService : ISuperPoweredService
    {
        private IUnitOfWork _unitOfwork;

        public SuperPoweredService(IUnitOfWork unitOfWork)
        {
            this._unitOfwork = unitOfWork;
        }

        public IEnumerable<SuperPower> Superpowers
        {
            get { return _unitOfwork.SuperPoweredRepository.GetAll(); }
        }

       

        public IEnumerable<SuperPower> GetSuperPowers()
        {
            return _unitOfwork.SuperPoweredRepository.GetAll();
        }
    }
}
