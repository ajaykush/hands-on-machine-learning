﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SuperPowered.BusinessLayer.Abstract;
using SuperPowered.DomainModel.Entities;

namespace SuperPowered.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [FormatFilter]
    public class SuperPowerController : ControllerBase
    {
        private readonly ISuperPoweredService SuperPoweredService;

        public SuperPowerController(ISuperPoweredService registrationService)
        {
            this.SuperPoweredService = registrationService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<SuperPowerDTO>> Get()
        {
            IEnumerable<SuperPower> lstsuperpowers = SuperPoweredService.GetSuperPowers();
            var lstsuperpowerswithType = new  List<SuperPowerDTO>();
            string superpowertype;
            foreach (SuperPower sp in lstsuperpowers)
            {
                superpowertype = sp.PersonName.ToUpper().Contains("D")  ? "Villain" : "Super-Hero";
                lstsuperpowerswithType.Add(new SuperPowerDTO(sp.PersonName, superpowertype));
            }

            return lstsuperpowerswithType;

        }

        [HttpGet("{name}")]
        public ActionResult<SuperPowerDTO> Get(string name)
        {
            IEnumerable<SuperPower> lstsuperpowers = SuperPoweredService.GetSuperPowers();
            SuperPower superpower = lstsuperpowers.First(p => p.PersonName==name);
            string superpowertype;
            superpowertype = superpower.PersonName.ToUpper().Contains("D") ? "Villain" : "Super-Hero";
            var obj = new SuperPowerDTO(superpower.PersonName, superpowertype);
            return obj;

        }

        [HttpGet]
        [Route("[action]")]
        public ActionResult<IEnumerable<SuperPowerDTO>> GetSuperHeroes()
        {
            IEnumerable<SuperPower> lstsuperpowers = SuperPoweredService.GetSuperPowers();
            var lstsuperpowerswithType = new List<SuperPowerDTO>();
            string superpowertype;
            foreach (SuperPower sp in lstsuperpowers)
            {
                if (!sp.PersonName.ToUpper().Contains("D"))
                {
                    superpowertype = "Super - Hero";
                    lstsuperpowerswithType.Add(new SuperPowerDTO(sp.PersonName, superpowertype));
                }
            }

            return lstsuperpowerswithType;

        }

        [HttpGet]
        [Route("[action]")]
        public ActionResult<IEnumerable<SuperPowerDTO>> GetVillains()
        {
            IEnumerable<SuperPower> lstsuperpowers = SuperPoweredService.GetSuperPowers();
            var lstsuperpowerswithType = new List<SuperPowerDTO>();
            string superpowertype;
            foreach (SuperPower sp in lstsuperpowers)
            {
                if (sp.PersonName.ToUpper().Contains("D"))
                {
                    superpowertype = "Villain";
                    lstsuperpowerswithType.Add(new SuperPowerDTO(sp.PersonName, superpowertype));
                }
            }

            return lstsuperpowerswithType;

        }

    }
}