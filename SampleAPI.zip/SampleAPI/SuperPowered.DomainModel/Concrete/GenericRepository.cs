﻿using SuperPowered.DomainModel.Abstract;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace SuperPowered.DomainModel.Concrete
{
    
    public class GenericRepository<TEntity> : IGenericRepository<TEntity>
    {
        internal FileContext _filecontext;
        

        public GenericRepository(FileContext context)
        {
            this._filecontext = context;
            
        }

       

        public IEnumerable<TEntity> GetAll()
        {
            
            return _filecontext.SuperPoweredList.Cast<TEntity>();
        }

        public void Dispose()
        {
            throw new System.NotImplementedException();
        }
    }
}
