﻿using System;
using System.Collections.Generic;
using System.Text;
using SuperPowered.DomainModel.Abstract;
using SuperPowered.DomainModel.Entities;


namespace SuperPowered.DomainModel.Concrete
{
    public class UnitOfWork : IUnitOfWork
    {
        protected IGenericRepository<SuperPower> _superpoweredRepository;
        private FileContext filecontext;
        public UnitOfWork()
        {
            filecontext = new FileContext();

        }

        public IGenericRepository<SuperPower> SuperPoweredRepository
        {
            get
            {
                if (_superpoweredRepository == null)
                    _superpoweredRepository = new GenericRepository<SuperPower>(filecontext);

                return _superpoweredRepository;
            }
        }
    }
}
