﻿using SuperPowered.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SuperPowered.DomainModel.Concrete
{
    public class FileContext
    {
        public IEnumerable<SuperPower> SuperPoweredList;

        public FileContext() {
            //var owners = File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Registrados.dat"));
            var superpoweredlist = File.ReadAllLines(@".\Data\Registrados.dat");
            var superpowers= new List<SuperPower>();
            foreach (string sp in superpoweredlist)
            {
                SuperPower spow = new SuperPower();
                spow.PersonName = sp;
                superpowers.Add(spow);
             }  
                SuperPoweredList = superpowers;
        }
  }
}
