﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace SuperPowered.DomainModel.Abstract
{
    public interface IGenericRepository<TEntity> : IDisposable 
    {
        
        IEnumerable<TEntity> GetAll();
    
    }


}
