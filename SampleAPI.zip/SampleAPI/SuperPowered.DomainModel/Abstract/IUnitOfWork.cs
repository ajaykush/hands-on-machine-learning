﻿using SuperPowered.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Text;


namespace SuperPowered.DomainModel.Abstract
{
    public interface IUnitOfWork
    {
        IGenericRepository<SuperPower> SuperPoweredRepository { get; }

    }

  
}
