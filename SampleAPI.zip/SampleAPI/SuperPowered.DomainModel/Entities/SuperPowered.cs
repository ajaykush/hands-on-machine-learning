﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperPowered.DomainModel.Entities
{
    public class SuperPower 
    {
        public String PersonName { get; set; }
     
    }

    public class SuperPowerDTO
    {


        public SuperPowerDTO(string personName, string persontype)
        {
            PersonName = personName;
            PersonType = persontype;
        }

        public String PersonName { get; set; }
        public String PersonType { get; set; }

    }
}
